# BERT Embeddings to boost your Danish NLP Game!
Package for making danish word+sentence embeddings with BERT 📜
